<?php
include 'layout/header.php';

if (!$_SESSION['login']) {
  header('location:login.php');
}

$id = $_GET['id'];

$query  = $conn->query("DELETE FROM perangkat WHERE id_perangkat = '$id'");

if ($query) {
  header('location:list_perangkat.php');
}

?>