<?php
include 'layout/header.php';

if (!$_SESSION['login']) {
  header('location:login.php');
}

$id = $_GET['id'];


if (isset($_POST['edit_perangkat']) && $_POST['edit_perangkat'] == "SIMPAN") {
  $judul     = $_POST['judul'];
  $gambar    = $_FILES['gambar']['name'];

  if (!empty($gambar)) {
    move_uploaded_file($_FILES['gambar']['tmp_name'],"../img/".$gambar);
    $query  = $conn->query("UPDATE perangkat SET gambar_perangkat = '$gambar' WHERE id_perangkat = '$id'", PDO::FETCH_ASSOC);
  }
  $query  = $conn->query("UPDATE perangkat SET jabatan = '$judul' WHERE id_perangkat = '$id'", PDO::FETCH_ASSOC);

  if ($query) {
    header('location:list_perangkat.php');
  }
}

//artikel
$result  = $conn->query("SELECT * FROM perangkat WHERE id_perangkat = '$id'", PDO::FETCH_ASSOC);
$row    = $result->fetch();

?>
<div class="judul_section">
  <h1>Edit Perangkat Desa</h1>
  <hr>
</div>
<form action="" method="post" enctype="multipart/form-data">
  <div class="textbox black">
    <label for="judul" >Jabatan</label>
    <input id="judul" type="text" name="judul" value="<?=$row['jabatan'];?>"><br>
  </div>
  <div class="textbox black">
    <label for="img">Gambar</label>
    <input id="img" type="file" name="gambar">
  </div>
  <input type="submit" name="edit_perangkat" value="SIMPAN" class="btn">
</form>
