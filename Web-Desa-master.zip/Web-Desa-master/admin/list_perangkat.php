<?php
include 'layout/header.php';

if (!$_SESSION['login']) {
  header('location:login.php');
}

$result  = $conn->query("SELECT * FROM perangkat ORDER BY jabatan DESC", PDO::FETCH_ASSOC);
// while ($row = $result->fetch()) {echo $row->judul_artikel;}
$row = $result->fetch();
?>
<div class="judul_section">
  <h1>Daftar Perangkat</h1>
  <hr>
</div>
<a href="tambah_perangkat.php" class="tombolplus">
  <i class="fa fa-plus"></i> Tambah Perangkat Desa
  <a href="index.php" class="tombolplus">
  <i></i> Dashboard
</a>
<br>

<table>
  <thead>
    <tr>
      <th>No.</th>
      <th>Jabatan</th>
      <th>Gambar</th>
      <th>Aksi</th>
    </tr>
  </thead>
  <tbody>
  <?php $num = 0; do{ $num++; ?>
    <tr>
      <td><?=$num;?></td>
      <td><?=$row['jabatan'];?></td>
      <td><img src="../img/<?=$row['gambar_perangkat'];?>" alt="<?=$row['gambar_perangkat'];?>" style="width:100px;"></td>
      <td>
        <a href="edit_perangkat.php?id=<?=$row['id_perangkat'];?>" class="edit">Edit</a> -
        <a href="hapus_perangkat.php?id=<?=$row['id_perangkat'];?>" class="delete">Hapus</a>
      </td>
    </tr>
    <?php }while($row = $result->fetch()); ?>
  </tbody>
</table>
