<?php
include 'layout/header.php';

if (!$_SESSION['login']) {
  header('location:login.php');
}

if (isset($_POST['tambah_perangkat']) && $_POST['tambah_perangkat'] == "TAMBAH") {
  $judul    = $_POST['judul'];
  $gambar   = $_FILES['img']['name'];

  move_uploaded_file($_FILES['img']['tmp_name'],"../img/".$gambar);

  $sql  = "INSERT INTO perangkat (jabatan, gambar_perangkat) VALUES (:judul, :img)";
  $query  = $conn->prepare($sql);
  $query->execute(array(
    ':judul' => $judul,
    ':img' => $gambar
  ));

  if ($query) {
    header('location:list_perangkat.php');
  }
}

$query  = $conn->query("SELECT * FROM kategori ORDER BY nama_kategori ASC",PDO::FETCH_ASSOC);
$data   = $query->fetch();

?>
<div class="judul_section">
  <h1>Tambah Perangkat</h1>
  <hr>
</div>
<form action="" method="post" enctype="multipart/form-data">
  <div class="textbox black">
    <label for="judul" >Jabatan</label>
    <input type="text" name="judul" id="judul" required>
  </div>
  <div class="textbox black">
    <label for="img">Gambar</label>
    <input type="file" name="img" required>
  </div>

  <input type="submit" name="tambah_perangkat" value="TAMBAH" class="btn">
</form>
