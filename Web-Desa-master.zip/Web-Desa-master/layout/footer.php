      </div>
    </div>

    <!-- Footer -->
    <div class="footer">
      <div class="rowflex">
        <div class="peta">
            <h1>Peta Desa Cimaung</h1>
          <img src="img/desa cimaung.jpg" width="300" height="150" frameborder="0" style="border:0"  allowfullscreen></iframe>
        </div>
        <div class="kutipan">
          <h1>Kutipan</h1>
          <img src="assets/images/Soekarno1.jpg" alt="Foto Ir. Soekarno">
          <p>Bung Karno pernah berkata <b>"Bangsa yang besar adalah bangsa yang menghargai jasa-jasa para pahlawannya"</b></p>
        </div>
        <div class="clear"></div>
      </div>
      <div class="copyright-section">
        <p>Copyright © 2022, <a href="" style="color:#92cf48;"><b>KKM 25 UNIBA</b></a> </p>
      </div>
  </div>
  </body>
</html>
