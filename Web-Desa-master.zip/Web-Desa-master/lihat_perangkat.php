<?php
include 'layout/header.php';


$query  = $conn->query("SELECT * FROM perangkat ORDER BY id_perangkat DESC", PDO::FETCH_ASSOC);
$data   = $query->fetch();

?>
<div class="container">
  <div class="content">
    <div class="artikel-section">
      <div class="judul">
        <h2><?=$data['jabatan'];?></h2>
      </div>
      <div class="imgartikel">
        <img src="img/<?=$data['gambar_perangkat'];?>">
      </div>
    </div> </div>
    <br>

<?php ?>
