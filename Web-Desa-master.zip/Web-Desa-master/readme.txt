*note

Membutuhkan koneksi internet. Ada beberapa komponen yang belum dilengkapi prefix browser, gunakan Mozilla Firefox.